USE [master]
GO
/****** Object:  Database [Partner]    Script Date: 03/15/2013 13:59:14 ******/
CREATE DATABASE [Partner] ON  PRIMARY 
( NAME = N'Partner', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\Partner.mdf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'Partner_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\Partner_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [Partner] SET COMPATIBILITY_LEVEL = 100
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Partner].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Partner] SET ANSI_NULL_DEFAULT OFF
GO
ALTER DATABASE [Partner] SET ANSI_NULLS OFF
GO
ALTER DATABASE [Partner] SET ANSI_PADDING OFF
GO
ALTER DATABASE [Partner] SET ANSI_WARNINGS OFF
GO
ALTER DATABASE [Partner] SET ARITHABORT OFF
GO
ALTER DATABASE [Partner] SET AUTO_CLOSE OFF
GO
ALTER DATABASE [Partner] SET AUTO_CREATE_STATISTICS ON
GO
ALTER DATABASE [Partner] SET AUTO_SHRINK ON
GO
ALTER DATABASE [Partner] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [Partner] SET CURSOR_CLOSE_ON_COMMIT OFF
GO
ALTER DATABASE [Partner] SET CURSOR_DEFAULT  GLOBAL
GO
ALTER DATABASE [Partner] SET CONCAT_NULL_YIELDS_NULL OFF
GO
ALTER DATABASE [Partner] SET NUMERIC_ROUNDABORT OFF
GO
ALTER DATABASE [Partner] SET QUOTED_IDENTIFIER OFF
GO
ALTER DATABASE [Partner] SET RECURSIVE_TRIGGERS OFF
GO
ALTER DATABASE [Partner] SET  DISABLE_BROKER
GO
ALTER DATABASE [Partner] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
GO
ALTER DATABASE [Partner] SET DATE_CORRELATION_OPTIMIZATION OFF
GO
ALTER DATABASE [Partner] SET TRUSTWORTHY OFF
GO
ALTER DATABASE [Partner] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO
ALTER DATABASE [Partner] SET PARAMETERIZATION SIMPLE
GO
ALTER DATABASE [Partner] SET READ_COMMITTED_SNAPSHOT OFF
GO
ALTER DATABASE [Partner] SET HONOR_BROKER_PRIORITY OFF
GO
ALTER DATABASE [Partner] SET  READ_WRITE
GO
ALTER DATABASE [Partner] SET RECOVERY SIMPLE
GO
ALTER DATABASE [Partner] SET  MULTI_USER
GO
ALTER DATABASE [Partner] SET PAGE_VERIFY CHECKSUM
GO
ALTER DATABASE [Partner] SET DB_CHAINING OFF
GO
USE [Partner]
GO
/****** Object:  User [WIN-BVPN2TOGTH1\MaestroWeb]    Script Date: 03/15/2013 13:59:14 ******/
CREATE USER [WIN-BVPN2TOGTH1\MaestroWeb] FOR LOGIN [WIN-BVPN2TOGTH1\MaestroWeb] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [redbox]    Script Date: 03/15/2013 13:59:14 ******/
CREATE USER [redbox] FOR LOGIN [redbox] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [IIS APPPOOL\partners.anfi.com]    Script Date: 03/15/2013 13:59:14 ******/
CREATE USER [IIS APPPOOL\partners.anfi.com] FOR LOGIN [IIS APPPOOL\partners.anfi.com]
GO
/****** Object:  Table [dbo].[lookup_codes]    Script Date: 03/15/2013 13:59:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[lookup_codes](
	[lookup_code_id] [numeric](18, 0) NOT NULL,
	[lookup_type] [nvarchar](50) NOT NULL,
	[code] [nvarchar](15) NOT NULL,
	[meaning] [nvarchar](50) NOT NULL,
	[oracle_lookup_code_id] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_partner_lookup_codes] PRIMARY KEY CLUSTERED 
(
	[lookup_code_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[clients]    Script Date: 03/15/2013 13:59:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



USE [Partner]
GO

/****** Object:  Table [dbo].[clients]    Script Date: 04/02/2013 15:45:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[clients](
	[Party_Id] [numeric](18, 0) NOT NULL,
	[First_Name] [nvarchar](50) NULL,
	[Last_Name] [nvarchar](50) NULL,
	[Prefix] [nvarchar](6) NULL,
	[Telephone] [nvarchar](25) NULL,
	[Mobil] [nvarchar](25) NULL,
	[Email] [nvarchar](100) NULL,
	[Nationality] [nvarchar](50) NULL,
	[Country] [nvarchar](50) NULL,
	[City] [nvarchar](150) NULL,
	[Address] [nvarchar](450) NULL,
	[Postal_Code] [nvarchar](50) NULL,
	[Line] [nvarchar](10) NULL,
	[Birth_date] [date] NULL,
	[Attribute1] [nvarchar](100) NULL,
	[Attribute2] [nvarchar](100) NULL,
	[Attribute3] [nvarchar](100) NULL,
	[Attribute4] [nvarchar](100) NULL,
	[Attribute5] [nvarchar](100) NULL,
	[Creation_Date] [datetime] NULL,
 CONSTRAINT [PK_Party_id] PRIMARY KEY CLUSTERED 

(
	[Party_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[partner_vouchers_interface]    Script Date: 03/15/2013 13:59:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[partner_vouchers_interface](
	[id] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[partner_lead_voucher_id] [numeric](18, 0) NOT NULL,
	[arrival_date] [date] NULL,
	[checkin_date] [date] NULL,
	[action] [nvarchar](50) NULL,
	[comments] [nvarchar](150) NULL,
	[creation_date] [datetime] NOT NULL,
 CONSTRAINT [PK_part_vouchers_interface] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[partner_leads]    Script Date: 03/15/2013 13:59:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[partner_leads](
	[partner_lead_id] [numeric](18, 0) NOT NULL,
	[partner_code] [nvarchar](50) NOT NULL,
	[start_date] [date] NOT NULL,
	[end_date] [date] NULL,
	[lead_Status] [nvarchar](10) NOT NULL,
	[price] [decimal](9, 2) NOT NULL,
	[currency] [nvarchar](3) NOT NULL,
	[comments] [nvarchar](50) NULL,
	[attribute1] [nvarchar](50) NULL,
	[attribute2] [nvarchar](50) NULL,
	[attribute3] [nvarchar](50) NULL,
	[attribute4] [nvarchar](50) NULL,
	[attribute5] [nvarchar](50) NULL,
	[last_update_date] [date] NOT NULL,
	[last_updated_by] [nvarchar](50) NOT NULL,
	[creation_date] [datetime] NOT NULL,
 CONSTRAINT [PK_partner_leads] PRIMARY KEY CLUSTERED 
(
	[partner_lead_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


/****** Object:  Table [dbo].[partner_lead_vouchers]    Script Date: 03/15/2013 13:59:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[partner_lead_vouchers](
	[partner_lead_voucher_id] [numeric](18, 0) NOT NULL,
	[partner_lead_id] [numeric](18, 0) NOT NULL,
	[party_id] [numeric](18, 0) NOT NULL,
	[voucher_number] [nvarchar](50) NULL,
	[start_date] [datetime] NOT NULL,
	[end_date] [datetime] NULL,
	[arrival_date] [datetime] NULL,
	[checkin_date] [datetime] NULL,
	[exchanged] [datetime] NULL,
	[due_date] [datetime] NULL,
	[cancelled] [datetime] NULL,
	[comments] [nvarchar](100) NULL,
	[last_update_date] [datetime] NOT NULL,
	[last_updated_by] [nvarchar](50) NOT NULL,
	[creation_date] [datetime] NOT NULL,
 CONSTRAINT [PK_partner_lead_vouchers] PRIMARY KEY CLUSTERED 
(
	[partner_lead_voucher_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[pa_update_lead_status]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[pa_update_lead_status]
	-- Add the parameters for the stored procedure here
	@partner_lead_id numeric, @new_lead_status nvarchar(10), @last_updated_by nvarchar(50)
	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
UPDATE
[partner].[dbo].[partner_leads]
SET 
lead_status=@new_lead_status,
last_update_date= GETDATE(),
last_updated_by=@last_updated_by
WHERE partner_lead_id= @partner_lead_id
	
END
GO
/****** Object:  StoredProcedure [dbo].[getLead]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[getLead]
	
	(
	@partner_lead_id nvarchar(50), @partnerCode nvarchar(50)
	)
	
AS		
	SELECT 
	[partner_lead_id],
	[partner_code], 
	[attribute1] Cref,
	[lead_Status],
	[price], 
	[currency],
	Convert(Char(10), [start_date] , 103) start_date,
	Convert(Char(10), end_Date , 103)end_Date,
	[lead_Status],
	[comments]
	FROM [partner_leads]
	WHERE  partner_lead_id= @partner_lead_id
	and  partner_code= @partnerCode
	RETURN

GO
/****** Object:  StoredProcedure [dbo].[getVouchers]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[getVouchers]
	
	(
	@partner_lead_id nvarchar(50),
	@partner_code nvarchar(50)
	)
	
AS		
	SELECT 
	
	       partner_lead_voucher_id,voucher_number,b.attribute1 as contract,
	        Convert(Char(10), arrival_date , 103)arrival_date,
		   Convert(Char(10), checkin_date , 103)checkin_date,
		   Convert(Char(10), due_date , 103)due_date
             
	  
	 FROM dbo.partner_lead_vouchers a, partner_leads   b
	 where a.partner_lead_id=b.partner_lead_id
	 and  a.partner_lead_id= @partner_lead_id
	and partner_code= @partner_code
	RETURN
GO
/****** Object:  StoredProcedure [dbo].[getVoucher]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[getVoucher]
	
	(
	@partner_lead_voucher_id nvarchar(50), @partner_code nvarchar(50)
	)
	
AS		
		SELECT 
	
	       partner_lead_voucher_id,a.voucher_number,b.attribute1 as contract,
	        Convert(Char(10), arrival_date , 103)arrival_date,
		   Convert(Char(10), checkin_date , 103)checkin_date,
		   Convert(Char(10), due_date , 103)due_date
             
	 FROM dbo.partner_lead_vouchers a, partner_leads   b
	 where a.partner_lead_id=b.partner_lead_id
	and partner_lead_voucher_id= @partner_lead_voucher_id
	and partner_code= @partner_code
	and 	   dateadd(d, 0, datediff(d, 0, due_Date))>  =  dateadd(d, 0, datediff(d, 0, getdate()))
	
	RETURN
GO
/****** Object:  StoredProcedure [dbo].[getLeads]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[getLeads]
	
	(
	@partnerCode nvarchar(50)
	)
	
AS		
	
SELECT distinct
	pl.[partner_lead_id],
    pl.[partner_code], 
	cl.[First_Name],
    cl.[Last_Name],
Convert(Char(10), pl.[start_date] , 103) start_date,
  Convert(Char(10), pl.end_Date , 103)end_Date ,
   pl.attribute1 Cref,
	pl.[lead_Status],
	pl.[comments]
  FROM [partner].[dbo].[partner_leads] pl,
 [partner].[dbo].[partner_lead_vouchers] plv,
 [partner].[dbo].clients cl  
  WHERE plv.partner_lead_id=pl.partner_lead_id
	and plv.party_id=cl.party_id
	and  partner_code= @partnerCode
		
	RETURN
GO
/****** Object:  StoredProcedure [dbo].[getClients]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[getClients]
	
	(
	@partner_lead_id nvarchar(50),
	@partnerCode nvarchar(50)
	)	
AS		

SELECT 
distinct
	   [First_Name]
      ,[Last_Name]
      ,[Telephone]
      ,[Mobil]
      ,[Email]
      ,[Nationality]
      ,[Line]
      ,Convert(Char(10), Birth_date , 103)Birth_date
      ,cl.[Attribute1]
      ,cl.[Attribute2]
      ,cl.[Attribute3]
      ,cl.[Attribute4]
      ,cl.[Attribute5]

  FROM [partner].[dbo].[partner_lead_vouchers] plv  
  ,[partner].[dbo].[partner_leads] pl, clients cl
  where plv.partner_lead_id=pl.partner_lead_id
  and plv.party_id=cl.party_id
  and pl.partner_lead_id= @partner_lead_id
  and partner_code= @partnerCode
	
	RETURN
GO
/****** Object:  StoredProcedure [dbo].[pa_update_vouchers_checkin_date_to_null]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[pa_update_vouchers_checkin_date_to_null]
	-- Add the parameters for the stored procedure here
	@partner_lead_voucher_id numeric,@last_updated_by nvarchar
	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
update
partner_lead_vouchers  
set last_update_date= GETDATE(),
checkin_date=null,
last_updated_by=@last_updated_by
where partner_lead_voucher_id= @partner_lead_voucher_id
	
END
GO
/****** Object:  StoredProcedure [dbo].[pa_update_vouchers_checkin_date]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[pa_update_vouchers_checkin_date]
	-- Add the parameters for the stored procedure here
	@partner_lead_voucher_id numeric,@checkin_date datetime, @last_updated_by nvarchar
	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
update
partner_lead_vouchers  
set last_update_date= GETDATE(),
checkin_date=@checkin_date,
last_updated_by=@last_updated_by
where partner_lead_voucher_id= @partner_lead_voucher_id
	
END
GO
/****** Object:  StoredProcedure [dbo].[pa_update_vouchers_arrival_date_to_null]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create  PROCEDURE [dbo].[pa_update_vouchers_arrival_date_to_null]
	-- Add the parameters for the stored procedure here
	@partner_lead_voucher_id numeric, @last_updated_by nvarchar
	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
update
partner_lead_vouchers  
set last_update_date= GETDATE(),
arrival_Date=null,

last_updated_by=@last_updated_by
where partner_lead_voucher_id= @partner_lead_voucher_id
	
END
GO
/****** Object:  StoredProcedure [dbo].[pa_update_vouchers_arrival_date]    Script Date: 03/15/2013 13:59:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[pa_update_vouchers_arrival_date]
	-- Add the parameters for the stored procedure here
	@partner_lead_voucher_id numeric,@arrival_date datetime, @last_updated_by nvarchar
	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
update
partner_lead_vouchers  
set last_update_date= GETDATE(),
arrival_Date=@arrival_Date,

last_updated_by=@last_updated_by
where partner_lead_voucher_id= @partner_lead_voucher_id
	
END
GO


USE [Partner]
GO
/****** Object:  Trigger [dbo].[partner_lead_voucher_trg]    Script Date: 03/15/2013 14:52:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Diego R�os>
-- Create date: <01/01/2013>

-- =============================================
ALTER TRIGGER [dbo].[partner_lead_voucher_trg] 
   ON  [dbo].[partner_lead_vouchers]
   AFTER  update
AS 
BEGIN

	SET NOCOUNT ON;
		
	Declare @arrival_Date As date;
	Declare @old_arrival_Date As date;
	Declare @checkin_Date As date;
	Declare @old_checkin_Date As date;
	Declare @code_meaning nvarchar(50);
	Declare @partner_lead_voucher_id numeric;


	Select	@arrival_Date = i.arrival_Date,
			@old_arrival_Date= d.arrival_Date,
			@checkin_Date = i.checkin_Date,
			@old_checkin_Date= d.checkin_Date,
			@partner_lead_voucher_id= i.partner_lead_voucher_id  From INSERTED i, deleted d
	where d.partner_lead_voucher_id= i.partner_lead_voucher_id;

	--*************** HANDLING START ARRIVAL_DATE ****************************
	--*************************************
	-- case null--> inform --**EXCHANGED***
	--*************************************
	IF  (@old_arrival_Date IS NULL  AND @arrival_Date IS NOT NULL)
		 
		BEGIN		
			UPDATE dbo.partner_lead_vouchers  set  EXCHANGEd =getdate(), COMMENTS= 'nuevo'
			WHERE partner_lead_voucher_id= @partner_lead_voucher_id;

			SELECT @code_meaning= meaning from lookup_codes where code= 'EXCHANGED'
		  
			--exchanged to history  
			INSERT INTO	dbo.partner_vouchers_interface
			SELECT 	  
			partner_lead_voucher_id	,
			arrival_date	,
			checkin_date	,
			'EXCHANGED',
			@code_meaning,
			getdate()
			FROM inserted;
	END;
	--******************************************
	-- case inform--> null --**UNDO EXCHANGED***
	--******************************************
	IF  @old_arrival_Date IS NOT NULL  AND @arrival_Date IS  NULL
		BEGIN
			UPDATE dbo.partner_lead_vouchers  set  exchanged =NULL, COMMENTS= 'cancelado'
			WHERE partner_lead_voucher_id= @partner_lead_voucher_id 
		  		
			SELECT  @code_meaning= meaning from lookup_codes where code= 'EXCHANGEDCXL'
		  		
			-- cancel exchanged to history
			INSERT INTO	dbo.partner_vouchers_interface
			SELECT
			partner_lead_voucher_id	,
			arrival_date	,
			checkin_date	,
			'EXCHANGEDCXL',
			@code_meaning,
			getdate()
			FROM INSERTED;      
	END;
		
	--******************************************
	-- case inform--> inform --***EXCHANGED MODIFIED***
	--******************************************
	IF  @old_arrival_Date IS NOT NULL  AND @arrival_Date IS NOT NULL
		 and (@old_arrival_Date != @arrival_Date )
		 BEGIN
		  	
	  		SELECT  @code_meaning= meaning from lookup_codes where code= 'EXCHANGEDMOD'
		  		
			-- MODIFICAR exchanged a historico
			INSERT INTO	dbo.partner_vouchers_interface
			SELECT
			partner_lead_voucher_id	,
			arrival_date	,
			checkin_date	,
			'EXCHANGEDMOD',
			@code_meaning,
			getdate()
			FROM INSERTED;  
			 
	END;

--********************************************	 
--*************** END ARRIVAL_DATE HANDLE ****
--********************************************	 

  
 --*************** HANDLING CHECKIN     
 --************************************* 
--*************************************
	-- case null--> inform --**CHECKIN***
	--*************************************
	IF  (@old_checkin_Date IS NULL  AND @checkin_Date IS NOT NULL)
		 
		BEGIN		

			SELECT @code_meaning= meaning from lookup_codes where code= 'CHECKIN'
			--exchanged to history  
			INSERT INTO	dbo.partner_vouchers_interface
			SELECT 	  
			partner_lead_voucher_id	,
			arrival_date	,
			checkin_date	,
			'CHECKIN',
			@code_meaning,
			getdate()
			FROM inserted;
	END;
    
    -- case inform--> null --**UNDO CHECKIN***
	--*************************************
	IF  (@old_checkin_Date IS NOT NULL  AND @checkin_Date IS  NULL)
		 
		BEGIN		

			SELECT @code_meaning= meaning from lookup_codes where code= 'CHECKINCXL'
			--exchanged to history  
			INSERT INTO	dbo.partner_vouchers_interface
			SELECT 	  
			partner_lead_voucher_id	,
			arrival_date	,
			checkin_date	,
			'CHECKINCXL',
			@code_meaning,
			getdate()
			FROM inserted;
	END;
    
     -- case inform--> inform --** CHECKIN CHANGED ***
	--*************************************
	IF  (@old_checkin_Date IS NOT NULL AND @checkin_Date IS NOT NULL)
		IF  (@old_checkin_Date != @checkin_Date )
		 
		BEGIN		

			SELECT @code_meaning= meaning from lookup_codes where code= 'CHECKINMOD'
			--exchanged to history  
			INSERT INTO	dbo.partner_vouchers_interface
			SELECT 	  
			partner_lead_voucher_id	,
			arrival_date	,
			checkin_date	,
			'CHECKINMOD',
			@code_meaning,			
			getdate()
			FROM inserted;
	END;
    
 
END 
    --*************** END CHECKIN HANDLE    
    




