Imports System.IO
Imports System.Xml.Serialization
Imports system.Data.OracleClient
Imports ClassFacturaBsFactura

Public Class ClsCrearFacturas
    Dim Lutil As New ClsUtil
    '   Dim Dt As New DatosFacturas.FacurasMPDataTable
    Dim cfac As New ConjuntoDatosFacturas

    Dim NumEmpresas As Int64 = 0
    Dim ErrorCodigoPostal As String


    Private Sub procesarMultiprint(ByVal IdClub As Integer, ByVal idcarga As Integer)
        Dim DrM As OracleDataReader
        Dim ContadorImpresion As Int16 = 0

        'obtenemos todos los registros del multiprint
        Lutil.Condicion = "  AND ORG_ID=" & IdClub & " and num_request= " & idcarga

        DrM = Lutil.obtenerMultiprint(Lutil.Condicion)

        Dim lEmpresa As New EmpresaType

        Dim NumFacturas As Integer = 0

        ' MsgBox(DrM.IsClosed)
        Do While DrM.Read
            lEmpresa.CIF = DrM.Item("club_cif") '  GetValue(0) ' org id
            If Not CheckExisteEmpresa(lEmpresa.CIF) Then
                AddEmpresa(DrM.Item("org_id"), lEmpresa.CIF)
            End If
            lEmpresa.CIF = DrM.Item("member_num") ' account number
            If Not CheckExisteCliente(lEmpresa.CIF) Then
                AddCliente(DrM)
            End If

            ' a�adir las facturas del cliente

            ReDim Preserve cfac.Facturas(NumFacturas)
            cfac.Facturas(NumFacturas) = ObtenerFacturas(DrM)
            NumFacturas = NumFacturas + 1

            If NumFacturas = 1 Then
                Lutil.EscribirXml(cfac, "ClassFacturaBsFactura.ConjuntoDatosFacturas", IdClub.ToString & "_" & DrM.Item("member_num") & "_" & ContadorImpresion.ToString, IdClub.ToString)
                lEmpresa = New EmpresaType
                ' ReDim ConjuntoDatosFacturas(0)
                cfac = New ConjuntoDatosFacturas
                NumEmpresas = 0
                NumFacturas = 0
                ReDim cfac.Empresas(0)
                ReDim cfac.Facturas(0)
                ContadorImpresion = ContadorImpresion + 1
                ' DrM = Nothing
            End If
            ' Debug.Print(NumFacturas)
        Loop

        Lutil.EscribirXml(cfac, "ClassFacturaBsFactura.ConjuntoDatosFacturas", IdClub.ToString & ContadorImpresion.ToString, IdClub.ToString)

    End Sub

    

    Private Function CheckExisteEmpresa(ByVal ClubCif As String) As Boolean
        Dim i As Integer

        Try
            For i = 0 To cfac.Empresas.Length - 1
                If cfac.Empresas(i).CIF = ClubCif Then
                    Return True
                End If
            Next
        Catch

        End Try
        Return False

    End Function

    Private Function CheckExisteCliente(ByVal AccountNumber As Integer) As Boolean
        Dim i As Integer
        Try
            For i = 0 To cfac.Empresas.Length - 1
                If cfac.Empresas(i).CIF = AccountNumber.ToString Then
                    Return True
                End If
            Next
        Catch
        End Try
        Return False

    End Function



    Private Function ObtenerCLiente(ByVal edr As OracleDataReader) As EmpresaType

        Dim fempresa As EmpresaType
        fempresa = New EmpresaType
        ''A�ADIMOS EMPRESAS  XXXX
        fempresa.CIF = "XXXX" & edr.Item("member_num") 'Lutil.CalculaNIF(edr.Item("member_num"))   ' accountnumber
        fempresa.RSocial = lUtil.BeginCData & edr.Item("mbr_name_surname") & lUtil.EndCData '  nombre
        fempresa.Direccion = lUtil.BeginCData & edr.Item("address1") & " " & edr.Item("address2") & " " & edr.Item("address3") & " " & edr.Item("address4") & lUtil.EndCData '"BARRANCO DE LA VERGA, S/N"
        ' Debug.Print(edr.Item("post_code"))
        fempresa.CP = edr.Item("post_code").ToString

        If edr.Item("post_code").ToString.Length > 10 Then
            fempresa.CP = edr.Item("post_code").ToString.Substring(0, 9)
            ErrorCodigoPostal = "**\" & ErrorCodigoPostal & edr.Item("post_code").ToString & "\**"
        End If

        fempresa.Localidad = Lutil.BeginCData & edr.Item("city").ToString & Lutil.EndCData
        fempresa.Provincia = Lutil.BeginCData & edr.Item("state").ToString & Lutil.EndCData
        fempresa.Pais = CType(System.Enum.Parse(GetType(Country), edr.Item("territory_code")), Country) 'Country.GB 'Country.ESP ' el pais se debe cambiar
        Return fempresa

    End Function
    Private Sub AddCliente(ByVal edr As OracleDataReader)
        ReDim Preserve cfac.Empresas(NumEmpresas)
        cfac.Empresas(NumEmpresas) = New EmpresaType
        cfac.Empresas(cfac.Empresas.Length - 1) = ObtenerCLiente(edr)
        NumEmpresas = NumEmpresas + 1

    End Sub

    Private Function ObtenerEmpresa(ByVal organizacion As Integer) As EmpresaType
        ''obtiene un dataset que devuelve las empresas
        Dim fempresa As EmpresaType = Nothing
        Dim sql As String

        Dim eDr As Data.OracleClient.OracleDataReader

        Dim dc As New DataCommand

        sql = "select name  rsocial,address_line_2 || ' '||  address_line_3 direccion,postal_code cp,town_or_city localidad, organization_id from hr_organization_units ou, hr.hr_locations_all la where ou.location_id=la.location_id  and organization_id=" & organizacion

        eDr = dc.obtenerDataReader(sql)

        While eDr.Read

            fempresa = New EmpresaType
            ''A�ADIMOS EMPRESA DE PRUEBA PARA XXXX
            ' fempresa.CIF = eDr.Item("club_cif") ' organizacion
            fempresa.RSocial = eDr.Item("rsocial") 'GetValue(0) '  "XXXX Sales S.L."
            fempresa.Direccion = lUtil.BeginCData & eDr.Item("direccion") & lUtil.EndCData '"XXXX, S/N"
            fempresa.CP = eDr.Item("cp")
            fempresa.Localidad = lUtil.BeginCData & eDr.Item("localidad") & lUtil.EndCData '"PLACE - LP"
            fempresa.Provincia = "XX XXX"
            fempresa.Pais = Country.ESP
            fempresa.Telefono = "ZZZZ"
            fempresa.Fax = "0000000"

            ' fempresa.RMercantil = "RMERCANTIL"
            ' fempresa(i).Tomo = "TOMO"
            'fempresa(i).Libro = "LIBRO"
            'fempresa(i).Seccion = " SECCION"
            'fempresa(i).Folio = "FOLIO"
            'fempresa(i).Hoja = " HOJA"
            ' i = i + 1
        End While

        eDr.Close()
        eDr = Nothing

        Return fempresa

    End Function
    Private Sub AddEmpresa(ByVal orgid As Integer, ByVal cif As String)
        ReDim Preserve cfac.Empresas(NumEmpresas)
        cfac.Empresas(NumEmpresas) = New EmpresaType
        cfac.Empresas(NumEmpresas) = ObtenerEmpresa(orgid)
        cfac.Empresas(NumEmpresas).CIF = cif

        NumEmpresas = NumEmpresas + 1
    End Sub

    ' Function ObtenerFacturas(ByVal drm As OracleDataReader) As FacturaGeneralType()
    Private Function ObtenerFacturas(ByVal dr As OracleDataReader) As FacturaGeneralType


        Dim NumeroFacturas As Integer = 0
        Dim TotalNetoFacturas As System.Decimal = 0
        Dim NExtension As Integer = 0

        Dim fFactura As FacturaGeneralType

        fFactura = New FacturaGeneralType

        ' crear data set con todas las facturas
        With fFactura

            .Nfactura = dr.Item("invoice_num")

            ' si fuera necesario cambiar la nomenclatura de la factura modificar este punto


            '.Nfactura = "R" || dr.Item("invoice_num") '


            .IdTipoMoneda = Currency.EUR
            .ImporteTotal = dr.Item("total_due") '

            .CIFEmisor = dr.Item("club_cif")  '
            .CIFReceptor = "XXXX" & dr.Item("member_num") 'Lutil.CalculaNIF(dr.Item("member_num"))  'dr.Item("member_num") '
            .IdTipoFactura = IdTipoFacturaType.FacturaComercial

            'introducir plantilla dependiendo del idioma
            'Factura Comercial 10 12 14 15 16 17 18
            'Factura Rectificativa  20 22 24 25 26 27 28
            Dim Plantilla As String
            Dim idiomaCli As String = ""

            Select Case dr.Item("language_name")
                Case "ES"
                    Plantilla = 10
                    idiomaCli = "SP"
                Case "EN"
                    Plantilla = 12
                    idiomaCli = "BR"
                Case "CS"
                    Plantilla = 12
                    idiomaCli = "BR"
                Case "FR"
                    Plantilla = 14
                    idiomaCli = "FR"
                Case "DE"
                    Plantilla = 15
                    idiomaCli = "GE"
                Case "IT"
                    Plantilla = 16
                    idiomaCli = "IT"
                Case "NO", "SV"
                    Plantilla = 17
                    idiomaCli = "NO"
                Case "NL"
                    Plantilla = 18
                    idiomaCli = "DU"
                Case Else
                    Plantilla = 12
                    idiomaCli = "BR"
            End Select

            .Plantilla = Plantilla ' factura comercial EN

            'ES: Espa�ol        4 ES
            'EN: Ingl�s           3 EN
            'FR: Franc�s        5 FR
            'GE: Alem�n        2 DE
            'IT: Italiano           6 IT
            'NO: Noruego       8 NO
            'DU: Holand�s    7 NL



            'Ejemplo <FacturaGeneral Nfactura="numfact" IdTipoMoneda="EUR" ImporteTotal="109.95"
            'CIFEmisor="D111111111" CIFReceptor="B00000000" Plantilla="xx"
            'IdTipoFactura="FacturaComercial">
            '�.
            '</FacturaGeneral>
            '1.1.1. Codificaci�n plantillas
            'En el proyecto se van a utilizar los siguientes idiomas:
            'ES:         Espa�ol()
            'EN:         Ingl�s()
            'FR:         Franc�s()
            'GE:         Alem�n()
            'IT:         Italiano()
            'NO:         Noruego()
            'DU:         Holand�s()
            '            TIPO(FACTURA)
            '            Plantilla()
            '            CASTELLANO()
            '            Plantilla()
            '            INGLES()
            '            Plantilla()
            '            FRANCES()
            '            Plantilla()
            '            ALEM�N()
            '            Plantilla()
            '            ITALIANO()
            '            Plantilla()
            '            NORUEGO()
            '            Plantilla()
            '            HOLAND�S()


            .Cabecera = New CabeceraType
            .Cabecera.Fecha = New FechaType

            .Cabecera.Fecha.Value = dr.Item("invoice_date")

            .Referencias = New ReferenciasType
            .Referencias.Proveedor = New ReferenciaProveedorType
            .Referencias.Proveedor.NreferenciaProveedor = dr.Item("invoice_num") '& "(REMINDER)"

            'bloque referido a la cuota de mantenimiento
            'a�adimos todos los conceptos de la factura
            '-- conceptos del a�o actual

            '-----------------------------------------
            Dim NumConcepto As Integer = 0
            Dim ContadorFacturas As Integer = 1
            Dim FacturaTS As String = ""
            Dim codigoContrato As String = ""

            Dim PrecioUnidadFactura As String
            Dim TotalFacturaTS As String
            Dim interesesFacturaTS As String
            Do
                Try
                    FacturaTS = "TS_INVOICE" & ContadorFacturas
                    PrecioUnidadFactura = "OA_INVOICE" & ContadorFacturas
                    interesesFacturaTS = "AD_LI_LINE" & ContadorFacturas
                    TotalFacturaTS = "AD_INVOICE" & ContadorFacturas

                    codigoContrato = dr.Item(FacturaTS)

                    ReDim Preserve .Conceptos(NumConcepto)
                    .Conceptos(NumConcepto) = New ConceptoType
                    .Conceptos(NumConcepto).referencia = "ACTUAL"
                    '.Conceptos(NumConcepto).Codigo = codigoContrato

                    ReDim Preserve .Conceptos(NumConcepto).Extensiones(0)
                    '.Extensiones. 
                    .Conceptos(NumConcepto).Extensiones(0) = New ExtensionType
                    .Conceptos(NumConcepto).Extensiones(0).nombre = "CodigoProducto"
                    .Conceptos(NumConcepto).Extensiones(0).Value = codigoContrato


                    .Conceptos(NumConcepto).PUnitario = dr.Item(PrecioUnidadFactura)
                    .Conceptos(NumConcepto).TotalNetoLinea = dr.Item(TotalFacturaTS)
                    .Conceptos(NumConcepto).PUnitarioSpecified = True
                    .Conceptos(NumConcepto).TotalNetoLineaSpecified = True



                    ReDim .Conceptos(NumConcepto).Cargos(0)

                    .Conceptos(NumConcepto).Cargos(0) = New CargoType
                    .Conceptos(NumConcepto).Cargos(0).TipoCargo = CargoTypeTipoCargo.Otros
                    .Conceptos(NumConcepto).Cargos(0).ImporteCargoSpecified = True
                    .Conceptos(NumConcepto).Cargos(0).ImporteCargo = dr.Item(interesesFacturaTS)
                    NumConcepto = NumConcepto + 1
                    ContadorFacturas = ContadorFacturas + 1
                Catch
                    Exit Do
                End Try
            Loop
            '-----------------------------------------

            '----------------------------- fin bloque actual
            ' ****************** Bloque refererido pendiente pago de a�os anteriores
            ContadorFacturas = 1
            TotalNetoFacturas = 0
            NExtension = 0

            Do
                Try
                    ReDim Preserve .Conceptos(NumConcepto)


                    If .Conceptos(NumConcepto) Is Nothing Then
                        .Conceptos(NumConcepto) = New ConceptoType
                    End If
                    .Conceptos(NumConcepto).referencia = "ANTERIOR"

                    FacturaTS = "PY_INVOICE" & ContadorFacturas
                    TotalFacturaTS = "AD_PY_INVOICE" & ContadorFacturas

                    codigoContrato = dr.Item(FacturaTS)

                    ReDim Preserve .Conceptos(NumConcepto).Extensiones(NExtension)
                    '.Extensiones. 
                    .Conceptos(NumConcepto).Extensiones(NExtension) = New ExtensionType
                    .Conceptos(NumConcepto).Extensiones(NExtension).nombre = "CodigoProducto"
                    .Conceptos(NumConcepto).Extensiones(NExtension).Value = codigoContrato
                    TotalNetoFacturas = TotalNetoFacturas + dr.Item(TotalFacturaTS)

                    .Conceptos(NumConcepto).TotalNetoLinea = TotalNetoFacturas
                    .Conceptos(NumConcepto).TotalNetoLineaSpecified = True

                    If ContadorFacturas <= 4 Then
                        NumConcepto = NumConcepto + 1
                        TotalNetoFacturas = 0
                    Else
                        'If ContadorFacturas = 5 Then
                        ' NumConcepto = NumConcepto + 1
                        'End If
                        NExtension = NExtension + 1
                    End If

                    ContadorFacturas = ContadorFacturas + 1
                Catch
                    Exit Do
                End Try
            Loop
            If NExtension > 0 Then NumConcepto = NumConcepto + 1
            ''********************************** fin bloque a�os anteriores

            '**********************************Bloque refererido pendiente Cuota XXXX Vacation Club SL'**********************************

            ContadorFacturas = 1
            TotalNetoFacturas = 0
            NExtension = 0

            ReDim Preserve .Conceptos(NumConcepto)
            .Conceptos(NumConcepto) = New ConceptoType
            .Conceptos(NumConcepto).referencia = "PACTUAL"

            Do
                Try
                    If ContadorFacturas = 1 Then
                        FacturaTS = "PVC_INVOICE"
                        TotalFacturaTS = "AD_PVC_INV"
                    Else
                        FacturaTS = "PVC_INVOICE" & ContadorFacturas
                        TotalFacturaTS = "AD_PVC_INV" & ContadorFacturas
                    End If
                    codigoContrato = dr.Item(FacturaTS)
                    ReDim Preserve .Conceptos(NumConcepto).Extensiones(NExtension)
                    '.Extensiones. 
                    .Conceptos(NumConcepto).Extensiones(NExtension) = New ExtensionType
                    .Conceptos(NumConcepto).Extensiones(NExtension).nombre = "CodigoProducto"
                    .Conceptos(NumConcepto).Extensiones(NExtension).Value = codigoContrato
                    TotalNetoFacturas = TotalNetoFacturas + dr.Item(TotalFacturaTS)
                    NExtension = NExtension + 1
                    ContadorFacturas = ContadorFacturas + 1
                Catch
                    Exit Do
                End Try
            Loop

            .Conceptos(NumConcepto).TotalNetoLinea = TotalNetoFacturas
            .Conceptos(NumConcepto).TotalNetoLineaSpecified = True

            NumConcepto = NumConcepto + 1
            ''********************************** FIN BLOQUE AVC ACTUAL

            ''*********************************'Bloque refererido pendiente Cuota XXXX Vacation Club SL a�os anteriores

            ContadorFacturas = 1
            TotalNetoFacturas = 0
            NExtension = 0


            ReDim Preserve .Conceptos(NumConcepto)
            .Conceptos(NumConcepto) = New ConceptoType
            .Conceptos(NumConcepto).referencia = "PANTERIOR"

            Do
                Try
                    FacturaTS = "PY_PVC_INVOICE" & ContadorFacturas
                    TotalFacturaTS = "AD_PY_PVC_INVOICE" & ContadorFacturas
                    codigoContrato = dr.Item(FacturaTS)
                    ReDim Preserve .Conceptos(NumConcepto).Extensiones(NExtension)
                    '.Extensiones. 
                    .Conceptos(NumConcepto).Extensiones(NExtension) = New ExtensionType
                    .Conceptos(NumConcepto).Extensiones(NExtension).nombre = "CodigoProducto"
                    .Conceptos(NumConcepto).Extensiones(NExtension).Value = codigoContrato
                    TotalNetoFacturas = TotalNetoFacturas + dr.Item(TotalFacturaTS)
                    NExtension = NExtension + 1
                    ContadorFacturas = ContadorFacturas + 1
                Catch
                    Exit Do
                End Try
            Loop

            .Conceptos(NumConcepto).TotalNetoLinea = TotalNetoFacturas
            .Conceptos(NumConcepto).TotalNetoLineaSpecified = True

            NumConcepto = NumConcepto + 1


            '*****************fin pendiente Cuota XXXX Vacation Club SL

            '*****************Bloque refererido pendiente Cuota Reservation (Tasa de Reserva)*****************
            ContadorFacturas = 1
            TotalNetoFacturas = 0
            NExtension = 0

            ReDim Preserve .Conceptos(NumConcepto)
            .Conceptos(NumConcepto) = New ConceptoType
            .Conceptos(NumConcepto).referencia = "RACTUAL"

            Do
                Try
                    If ContadorFacturas = 1 Then
                        FacturaTS = "RES_INVOICE"
                        TotalFacturaTS = "AD_RES_INV"
                    Else
                        FacturaTS = "RES_INVOICE" & ContadorFacturas
                        TotalFacturaTS = "AD_RES_INV" & ContadorFacturas
                    End If
                    codigoContrato = dr.Item(FacturaTS)
                    ReDim Preserve .Conceptos(NumConcepto).Extensiones(NExtension)
                    '.Extensiones. 
                    .Conceptos(NumConcepto).Extensiones(NExtension) = New ExtensionType
                    .Conceptos(NumConcepto).Extensiones(NExtension).nombre = "CodigoProducto"
                    .Conceptos(NumConcepto).Extensiones(NExtension).Value = codigoContrato
                    TotalNetoFacturas = TotalNetoFacturas + dr.Item(TotalFacturaTS)
                    NExtension = NExtension + 1
                    ContadorFacturas = ContadorFacturas + 1
                Catch
                    Exit Do
                End Try
            Loop

            .Conceptos(NumConcepto).TotalNetoLinea = TotalNetoFacturas
            .Conceptos(NumConcepto).TotalNetoLineaSpecified = True

            NumConcepto = NumConcepto + 1
            '*****************fin reservation********************************************************************

            ' *****************Bloque refererido pendiente Cuota Reservation (Tasa de Reserva) a�os anteriores*****************
            ContadorFacturas = 1
            TotalNetoFacturas = 0
            NExtension = 0


            ReDim Preserve .Conceptos(NumConcepto)
            .Conceptos(NumConcepto) = New ConceptoType
            .Conceptos(NumConcepto).referencia = "RANTERIOR"

            Do
                Try
                    FacturaTS = "PY_RES_INVOICE" & ContadorFacturas
                    TotalFacturaTS = "AD_PY_RES_INVOICE" & ContadorFacturas
                    codigoContrato = dr.Item(FacturaTS)
                    ReDim Preserve .Conceptos(NumConcepto).Extensiones(NExtension)
                    '.Extensiones. 
                    .Conceptos(NumConcepto).Extensiones(NExtension) = New ExtensionType
                    .Conceptos(NumConcepto).Extensiones(NExtension).nombre = "CodigoProducto"
                    .Conceptos(NumConcepto).Extensiones(NExtension).Value = codigoContrato
                    TotalNetoFacturas = TotalNetoFacturas + dr.Item(TotalFacturaTS)
                    NExtension = NExtension + 1
                    ContadorFacturas = ContadorFacturas + 1
                Catch
                    Exit Do
                End Try
            Loop

            .Conceptos(NumConcepto).TotalNetoLinea = TotalNetoFacturas
            .Conceptos(NumConcepto).TotalNetoLineaSpecified = True

            '  NumConcepto = NumConcepto + 1
            ' -----------------fin bloque pendiente Cuota Reservation (Tasa de Reserva)
            'impuestos()
            ReDim .Impuestos(0)
            .Impuestos(0) = New ImpuestoType

            ' ''.Impuestos(0).BaseImponible = 97.25
            ' ''.Impuestos(0).BaseImponibleSpecified = True
            .Impuestos(0).TipoImpuesto = TipoImpuestoType.IGIC
            .Impuestos(0).TasaImpuesto = 7
            ' ''.Impuestos(0).ImporteImpuesto = 15.56
            .Impuestos(0).ImporteImpuestoSpecified = True

            '' '' forma de pago
            ' ''ReDim .Vencimientos(0)
            ' ''.Vencimientos(0) = New VencimientoType

            ' ''.Vencimientos(0).FormaPago = VencimientoTypeFormaPago.Transferencia
            ' ''.Vencimientos(0).FormaPagoSpecified = True

            ReDim .Extensiones(0)
            .Extensiones(0) = New ExtensionType

            .Extensiones(0).nombre = "Code"
            .Extensiones(0).Value = dr.Item("member_num")

            .Textos = New FacturaGeneralTypeTextos

            .Textos.Texto2 = dr.Item("INVOICE_YEAR") '2009:
            .Canales = New CanalesType
            .Canales.Papel = New PapelType
            .Canales.Papel.Pasarela = 1
			
            '.Canales.Papel.copias = 2
            '    .Canales.Email = New EmailType
            '   .Canales.Email.type = typeEmail.FACTURA
            '  ReDim .Canales.Email.DirEmail(0)
            ' .Canales.Email.DirEmail(0) = Lutil.BeginCData & "" & Lutil.EndCData

            'datos de direcci�n del cliente
            .Recepcion = New RecepcionType
            .Recepcion.CIFRecepcion = "XXXX" & dr.Item("member_num") 'Lutil.CalculaNIF(dr.Item("member_num"))  '"44306087Z" 'dr.Item("member_num")     '"B99999999"
            .Recepcion.RSocialRecepcion = Lutil.BeginCData & dr.Item("mbr_name_surname") & Lutil.EndCData '"Matchmind, S.A." ' nombre del cliente
            .Recepcion.DireccionRecepcion = Lutil.BeginCData & dr.Item("address1") & " " & dr.Item("address2") & " " & dr.Item("address3") & " " & dr.Item("address4") & Lutil.EndCData '"BARRANCO DE LA VERGA, S/N"

            .Recepcion.CPRecepcion = dr.Item("post_code").ToString  '"08370"

            If dr.Item("post_code").ToString.Length > 10 Then
                .Recepcion.CPRecepcion = "" 'dr.Item("post_code").ToString.Substring(0, 9)
                '  ErrorCodigoPostal = "**\" & ErrorCodigoPostal & dr.Item("post_code").ToString & "\**"
                .Recepcion.LocalidadRecepcion = dr.Item("post_code") & " "
            End If


            .Recepcion.LocalidadRecepcion = Lutil.BeginCData & .Recepcion.LocalidadRecepcion & dr.Item("city").ToString & Lutil.EndCData '"Barcelona"
            .Recepcion.ProvinciaRecepcion = Lutil.BeginCData & dr.Item("state").ToString & Lutil.EndCData '"Barcelona"
            .Recepcion.PaisRecepcion = Lutil.BeginCData & dr.Item("country") & Lutil.EndCData '"Espa�a"

            'datos direccion de la empresa emisora

            ReDim .ConjuntoDatosEmpresas(1)
            .ConjuntoDatosEmpresas(0) = New DatosEmpresaType
            .ConjuntoDatosEmpresas(0).CIF = dr.Item("club_cif")
            .ConjuntoDatosEmpresas(0).SRSocial = dr.Item("club_name")
            .ConjuntoDatosEmpresas(0).SDireccion = "Barranco de la verga s/n"
            .ConjuntoDatosEmpresas(0).SCpostal = 35120
            .ConjuntoDatosEmpresas(0).SLocalidad = "Mog�n"
            .ConjuntoDatosEmpresas(0).SProvincia = "Las Palmas"
            .ConjuntoDatosEmpresas(0).SPais = Country.ESP
            .ConjuntoDatosEmpresas(0).STelefono = "928291570"
            .ConjuntoDatosEmpresas(0).SFax = ""
            .ConjuntoDatosEmpresas(0).SRMercantil = ""
            .ConjuntoDatosEmpresas(0).STomo = ""
            .ConjuntoDatosEmpresas(0).SLibro = ""
            .ConjuntoDatosEmpresas(0).SSeccion = ""
            .ConjuntoDatosEmpresas(0).SFolio = ""
            .ConjuntoDatosEmpresas(0).SHoja = ""

            'datos direccion del cliente
            .ConjuntoDatosEmpresas(1) = New DatosEmpresaType
            .ConjuntoDatosEmpresas(1).CIF = "XXXX" & dr.Item("member_num") 'Lutil.CalculaNIF(dr.Item("member_num"))  ' "44306087Z" 'dr.Item("member_num")    ' account number
            .ConjuntoDatosEmpresas(1).SRSocial = Lutil.BeginCData & dr.Item("mbr_name_surname") & Lutil.EndCData ' nombre
            .ConjuntoDatosEmpresas(1).SDireccion = Lutil.BeginCData & dr.Item("address1") & " " & dr.Item("address2") & " " & dr.Item("address3") & " " & dr.Item("address4") & Lutil.EndCData '"BARRANCO DE LA VERGA, S/N"
            .ConjuntoDatosEmpresas(1).SCpostal = dr.Item("post_code").ToString

            .ConjuntoDatosEmpresas(1).SCpostal = dr.Item("post_code").ToString  '"08370"

            If dr.Item("post_code").ToString.Length > 10 Then
                .ConjuntoDatosEmpresas(1).SCpostal = dr.Item("post_code").ToString.Substring(0, 9)
                ErrorCodigoPostal = "**\" & ErrorCodigoPostal & dr.Item("post_code").ToString & "\**"
            End If

            .ConjuntoDatosEmpresas(1).SLocalidad = Lutil.BeginCData & dr.Item("city") & " " & dr.Item("state") & Lutil.EndCData

            .ConjuntoDatosEmpresas(1).SPais = CType(System.Enum.Parse(GetType(Country), dr.Item("territory_code")), Country) 'Country.GB 'Country.ESP ' el pais se debe cambiar

            'documentos adjuntos
            ReDim .DocumentosAdjuntos(0)
            .DocumentosAdjuntos(0) = New DocumentoAdjuntoType

            .DocumentosAdjuntos(0).encoding = DocumentoAdjuntoTypeEncoding.BASE64
            .DocumentosAdjuntos(0).IdTipoFactura = IdTipoFacturaType.FacturaComercial
            .DocumentosAdjuntos(0).compression = DocumentoAdjuntoTypeCompression.NONE
            .DocumentosAdjuntos(0).format = DocumentoAdjuntoTypeFormat.pdf
            .DocumentosAdjuntos(0).ImpDocAdjunto = True
            .DocumentosAdjuntos(0).ImpDocAdjuntoSpecified = True
            .DocumentosAdjuntos(0).Value = Lutil.BeginCData & convertiraBase64(idiomaCli, dr.Item("club_cif")) & Lutil.EndCData

            '  Debug.Print(dr.Item("language_name"))

        End With


        Return fFactura


    End Function

    Private Function convertiraBase64(ByVal idioma As String, ByVal club As String) As String
        Dim _binaryStr As String = ""
        Try
            'devolver dependiendo del idioma del cliente
            Dim _stream As System.IO.FileStream

            Dim NomClub As String = ""


            club = club.Replace("-", "")
            club = club.Replace("ES35625136", "B35625136")

            Select Case club
                Case "H35904580" ' XXXX CLUB E Activa 06/10/2008  H-35904580 130
                    NomClub = "AE"
                Case "H35740000" ' ESP CLUB 2 XXXX Activa 06/10/2008 '84 H35740000
                    NomClub = "GA"
                Case "G35584960" 'ESP CLUB 3 XXXX Activa 06/10/2008 '85 G35584960
                    NomClub = "TA"
                Case "N0064972C" 'ESP CLUB 4 XXXX Activa 21/10/2008 '86 G0064972C
                    NomClub = "PA"
                Case "N0064505A" ' ESP XXXX CLUB 5 Activa 21/10/2008 '87 G0064505-A
                    NomClub = "AB"
                Case "B35625136" 'XXXX SALES ' 81
                    NomClub = "AS"
                Case "B35780055" ' AVC' 88
            End Select



            _stream = New System.IO.FileStream("c:\bsfactura\pdf\" & NomClub & " " & idioma & ".pdf", FileMode.Open, FileAccess.Read)

            Dim _buffer(_stream.Length) As Byte
            Dim bytesRead As Long

            bytesRead = _stream.Read(_buffer, 0, CInt(_stream.Length))
            _stream.Close()


            _binaryStr = Convert.ToBase64String(_buffer, 0, _buffer.Length)


        Catch
            MsgBox("Ha habido un error con el pdf adjunto")


        End Try

        Return _binaryStr

        'Este metodo me convierte binarios a un buffer y luego a un
        'string de caracteres.

    End Function



    Sub GenerarFacturas(ByVal IdClub As Integer, ByVal IdCarga As Integer)
        Dim t1 As Date, t2 As Date
        t1 = Now
        procesarMultiprint(IdClub, IdCarga)

        t2 = Now
        Debug.Print("tiempo total:" & DateDiff(DateInterval.Second, t1, t2))
        Debug.Print("ini:" & t1)
        Debug.Print("fin:" & t2)


        Debug.Print("errores es " & ErrorCodigoPostal)
    End Sub
End Class

